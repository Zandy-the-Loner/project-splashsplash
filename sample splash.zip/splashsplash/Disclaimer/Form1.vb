﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim oForm As New Dialog1

        Dim aForm As New Form1

        oForm.Show()

        Me.Hide()
    End Sub
End Class
